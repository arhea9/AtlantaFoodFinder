from django.urls import path, include
from . import views
from rest_framework.routers import DefaultRouter
from .views import RestaurantViewSet

router = DefaultRouter()
router.register(r'restaurants', RestaurantViewSet)

urlpatterns = [
    path('', views.landing_page, name='landing_page'),
    path('map/', views.map_view, name='map'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('api/', include(router.urls)),

]
