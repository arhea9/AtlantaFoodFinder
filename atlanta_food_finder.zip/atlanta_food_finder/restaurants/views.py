from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from rest_framework import viewsets
from .models import Restaurant
from .serializers import RestaurantSerializer
from django.conf import settings

def landing_page(request):
    return render(request, 'restaurants/landing_page.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()  # Save the new user
            login(request, user)  # Log the user in after successful registration
            return redirect('map')  # Redirect to the map page after registration
    else:
        form = UserCreationForm()
    return render(request, 'restaurants/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)  # Log the user in
            return redirect('map')  # Redirect to the map page
    else:
        form = AuthenticationForm()
    return render(request, 'restaurants/login.html', {'form': form})

# Create your views here.

def map_view(request):
    context = {
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY,
    }
    return render(request, 'restaurants/map.html', context)

class RestaurantViewSet(viewsets.ModelViewSet):
    queryset = Restaurant.objects.all()
    serializer_class = RestaurantSerializer
